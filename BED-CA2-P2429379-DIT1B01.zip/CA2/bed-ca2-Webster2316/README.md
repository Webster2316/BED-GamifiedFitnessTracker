# Starter Repository for Assignment
You are required to build your folder structures for your project.
index page shows challenges which is connected to show all challnges.js and challenge.js

review page is connected to getReview.js and review.js
login page connected to login
register page is connected to register
user page is for userCompletion connected to usercompletion.js
profile page to show login is complete
fashion page to purchase clothing articles is connected getFashion.js 

userNavbar qryCmd and getcurrent url is so ensure smooth running